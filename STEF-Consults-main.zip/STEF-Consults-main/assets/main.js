//testimonies array....................
const testimonies = [
  {
    title: "Personalized Guidance that Made a Difference",
    message:
      "Thanks to the guidance of STEF Consults, I found the perfect university and program that aligned with my goals. Their personalized approach made all the difference!",
    user: "Bolaji Adesanya",
    user_location: "Lagos, NG",
  },
  {
    title: "Comprehensive Support Every Step of the Way",
    message:
      "I can't thank STEF Consults enough for their continuous support. From selecting colleges to crafting compelling essays, they were with me every step of the way.",
    user: "Olawale Oluwamayowa",
    user_location: "Abeokuta, NG",
  },
  {
    title: "Turning Dreams into Reality with Expertise",
    message:
      "STEF Consults in-depth knowledge about different universities and their strong connections proved invaluable. With their help, I got accepted into a prestigious institution with a scholarship.",
    user: "Chinyere Onome",
    user_location: "Lagos, NG",
  },
  {
    title: "A Seamless Transition for International Students",
    message:
      "As an international student, I was overwhelmed by the application process in a foreign country. STEF Consults international expertise made the transition seamless and less daunting.",
    user: "Babayemi Oluwatofunmi",
    user_location: "Oyo, NG",
  },
  {
    title: "Empowering Academic Journeys through Dedicated Support",
    message:
      "STEF Consults dedication to helping students reach their potential is commendable. Their insights and assistance were instrumental in shaping my academic journey.",
    user: "David Oluwatimilehin",
    user_location: "Lagos, NG",
  },
  {
    title: "Navigating the College Maze Made Easy",
    message:
      "I was lost in the sea of college options, but STEF Consults expert advice helped me navigate the application process smoothly. I'm now studying at my dream university.",
    user: "Okeke Chiamaka",
    user_location: "Akwa, NG",
  },
  {
      "title": "Exceptional Support and Preparation",
      "message": "They were incredibly easy to work with and provided exceptional support throughout the entire interview process ensuring I was well-prepared and informed at every step.",
      "user": "Chidinma Adekunle",
      "user_location": "Lagos, Nigeria"
  },
  {
      "title": "Fantastic Opportunity Achieved",
      "message": "Thanks to their assistance, I landed a fantastic opportunity.",
      "user": "Oluwaseun Ogunleye",
      "user_location": "Abuja, Nigeria"
  },
  {
      "title": "Highly Recommended Services",
      "message": "I highly recommend their services to anyone there Team provided consistent support throughout the entire job process.",
      "user": "Emeka Okonkwo",
      "user_location": "Port Harcourt, Nigeria"
  },
  {
      "title": "Helped Me Reach My Potential",
      "message": "I do believe their help has allowed me to reach my potential, and I would definitely recommend them to anyone.",
      "user": "Nkechi Onyekwere",
      "user_location": "Enugu, Nigeria"
  },
  {
      "title": "Excellent Experience",
      "message": "I had an excellent experience with this recruitment company.",
      "user": "Chinedu Eze",
      "user_location": "Kano, Nigeria"
  },
  {
      "title": "Exceptional Support and a Fantastic Opportunity",
      "message": "They were incredibly easy to work with and provided exceptional support throughout the entire interview process ensuring I was well-prepared and informed at every step. Thanks to their assistance, I landed a fantastic opportunity.",
      "user": "Ifunanya Obi",
      "user_location": "Ibadan, Nigeria"
  },
  {
      "title": "Absolutely Excellent Service",
      "message": "I highly recommend their services to anyone. Absolutely excellent service! So enthusiastic and passionate about what they do. Thank you so much.",
      "user": "Abdul Suleiman",
      "user_location": "Jos, Nigeria"
  },
  {
      "title": "Great Feedback and Follow-ups",
      "message": "I also had great feedback and follow-ups at every stage of my application process. I would recommend STEF Consults to any future graduates.",
      "user": "Fatima Yusuf",
      "user_location": "Kaduna, Nigeria"
  },
  {
      "title": "Wonderful Experience for My Career",
      "message": "My experience with STEF Consults was wonderful and extremely helpful for my career, always there for me in my employment process.",
      "user": "Olawale Bakare",
      "user_location": "Abeokuta, Nigeria"
  },
  {
      "title": "Enhanced Chances for Graduate Position",
      "message": "Their professionalism enhanced my chances of getting my graduate position ahead of others.",
      "user": "Chukwudi Nwosu",
      "user_location": "Calabar, Nigeria"
  }
];

//for testimony propagation
if (document.querySelector(".testimony-container")) {
  let index = 0;

  const populateDetails = () => {
    document.getElementById("testimony-header").innerHTML =
      testimonies[index].title;
    document.getElementById("testimony-message").innerHTML =
      testimonies[index].message;
    document.getElementById("testimony-user").innerHTML =
      testimonies[index].user;
    document.getElementById("testimony-user-location").innerHTML =
      testimonies[index].user_location;
  };

  populateDetails();

  document.getElementById("nextTestimony").addEventListener("click", () => {
    if (index == testimonies.length - 1) {
      index = 0;
    } else {
      index++;
    }

    populateDetails();
  });

  document.getElementById("prevTestimony").addEventListener("click", () => {
    if (index == 0) {
      index = testimonies.length - 1;
    } else {
      index--;
    }

    populateDetails();
  });
}

//initializing the AOS
AOS.init();

//for the counter
if (document.querySelectorAll(".counter")[0]) {
  const length = document.querySelectorAll(".counter").length;

  for (let i = 0; i < length; i++) {
    let element = document.querySelectorAll(".counter")[i];
    let upTo = element.getAttribute("data-count-end");
    upTo = parseInt(upTo);

    let current = 0;

    const update = () => {
      element.innerHTML = ++current;

      if (current == upTo) {
        clearInterval(counts);
      }
    };

    let counts = setInterval(update);
  }
}

//for contact form
if (document.getElementById("contactForm")) {
  const contactForm = document.getElementById("contactForm");
  const contactFormBtn = document.getElementById("contactForm-button");

  contactForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const name = document.getElementById("name").value;
    const emailAddress = document.getElementById("emailAddress").value;
    const phoneNumber = document.getElementById("phoneNumber").value;
    const subject = document.getElementById("subject").value;
    const message = document.getElementById("message").value;

    contactFormBtn.disabled = true;
    contactFormBtn.innerHTML =
      '<div class="d-flex align-items-center gap-1"><span class="loader"></span> Sending...</div>';

    const data = {
      name,
      emailAddress,
      phoneNumber,
      subject,
      message,
      _subject: `JUST_IN: [${subject.toUpperCase()}]`,
      _template: "table",
    };

    const url = "https://formsubmit.co/ajax/stefeducationalconsults@gmail.com";

    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    console.log(response);

    if (response.status) {
      alert(
        "Your message was sent successfully ✅. Await a reply within 24 to 48 hours."
      );
    } else {
      alert(
        "Unable to complete request. Try refreshing the page and try again"
      );
      throw new Error(response);
    }

    contactFormBtn.disabled = false;
    contactFormBtn.innerHTML = "Get in Touch &raquo;";
  });
}

//for navbar toggle
if (document.querySelector(".nav-toggle")) {
  const nav_content = document.querySelectorAll(".nav-content")[0];

  document.querySelectorAll(".nav-toggle")[0].addEventListener("click", () => {
    nav_content.style.height = "100vh";
  });

  document.querySelectorAll(".close-nav")[0].addEventListener("click", () => {
    nav_content.style.height = "0vh";
  });
}
