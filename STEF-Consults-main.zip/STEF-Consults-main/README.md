## StefConsults

A fully functional website for STEF Consultation. This was built using `HTML + CSS + JavaScript`

## Installation and Setup Instructions

Clone down this repository.
